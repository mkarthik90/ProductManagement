package com.witty.service;

import com.witty.command.Regcommand;
public interface RegFun {
	public void addEmployee(Regcommand regcommand);
}
